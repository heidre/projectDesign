document.addEventListener('DOMContentLoaded', function() {
  document.getElementById("scorePage").addEventListener('click', () => {
	  
	function countSentences() {
        //You can play with your DOM here or check URL against your regex
        //return document.body.innerHTML;
        var sentences = [
		"(\\w+)([.!?][^a-z\\d\_\&\<\>\"\']?)"
		];
		var exceptions = [
		"Mrs.",
		"Mr.",
		"Dr.",
		"Jr.",
		"Sr.",
		"e.g.",
		"i.e.",
		"e.x."
		];
		
        //this line will look for all <p> elements
		var htmlElements = ["p","li","hi","td"];
		//count instances
		var counter = 0;
		var results = {};
        for(var h = 0; h < htmlElements.length; h++) {
			var elements = document.getElementsByTagName(htmlElements[h])
			for(var i = 0; i < elements.length; i++) {
			for(var p = 0; p < sentences.length; p++) {
				var text = elements[i].innerHTML;
					var newText = '';
						var re = eval( '/' + sentences[p] + '/g');
						newText = text.replace(re, '$1<span class="sentences">$2<\/span>') ;
					if (newText !== text) {
						counter++;
						elements[i].innerHTML = newText;
					}
				}
			}
        }
		
		results.counter = counter;
		results.url = window.location.href;
	return results;
	}


    //We have permission to access the activeTab, so we can call chrome.tabs.executeScript:
    chrome.tabs.executeScript({
        code: '(' + countSentences + ')();' //argument here is a string but function.toString() returns function's code
    }, (results) => {
        //Here we have just the innerHTML and not DOM structure
			console.log(JSON.stringify(results));
		var passiveCount = parseInt(document.getElementById("pageResults").innerHTML);
		var sentenceCount = results.counter;
		if (passiveCount !== 0 && sentenceCount !== 0) {
			var finalScore = (passiveCount/sentenceCount).toFixed(4)*100 + "%";
			console.log(sentenceCount/passiveCount + " " + finalScore);
			document.getElementById("scoreResults").innerHTML = finalScore;
			document.getElementById("link1").href = "https://twitter.com/intent/tweet?text=" + encodeURI(finalScore) + '%20Passified:%20' + results.url;	
		}
    });
  }, false);
}, false);

//function countSentences () {
	//var collectedSentences = []; +
	//var htmlElements = ["p","li","td","h1"];
	//for(var h = 0; h < htmlElements.length; h++) {
		//var temp = document.getElementsByTagName(htmlElements[h]);
		//for (var t = 0; t < temp.length; t++) {
			//collectedSentences.push(temp[t].innerHTML);
		//}
	//}
